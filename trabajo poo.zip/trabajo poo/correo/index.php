<?php
include ('./correo.php');

correo('lsgarcia@uniempresarial.edu.co','prueba php', 'mensaje');

?>